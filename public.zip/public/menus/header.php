<nav class="nav" aria-label="Navigation principale">
  <h1 class="logo"><a href="/">CrewUp</a></h1>

  <ul class="main-menu">
    <li><a href="/">Accueil</a></li>
    <li><a href="/annonces.php">Annonces</a></li>
    <li><a href="/terrains.php">Terrains</a></li>
  </ul>

  <a class="btn-inscription" href="/account/dashboard.php">Inscription gratuite</a>
</nav>
