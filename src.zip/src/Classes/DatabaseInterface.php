<?php

interface DatabaseInterface
{
    public function getPdo(): \PDO;
}