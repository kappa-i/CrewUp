<?php
spl_autoload_register(function ($class) {
    $class = ltrim($class, '\\');

    // Mappe "Classes\" -> "src/Classes/"
    $prefix = 'Classes\\';
    $base   = __DIR__ . '/../';

    if (strncmp($class, $prefix, strlen($prefix)) === 0) {
        $relative = substr($class, strlen($prefix));                 // e.g. "Events\Event"
        $file = $base . 'Classes/' . str_replace('\\', '/', $relative) . '.php';
    } else {
        // fallback simple pour les classes vraiment globales (si tu en as)
        $file = $base . 'Classes/' . str_replace('\\', '/', $class) . '.php';
    }

    if (is_file($file)) require_once $file;
});
